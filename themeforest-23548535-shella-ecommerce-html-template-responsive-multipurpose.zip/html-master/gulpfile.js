'use strict';

var gulp = require('gulp'),
    watch = require('gulp-watch'),
    prefixer = require('gulp-autoprefixer'),
    uglify = require('gulp-uglify'),
    extReplace = require('gulp-ext-replace'),
    sass = require('gulp-sass'),
    //sourcemaps = require('gulp-sourcemaps'),
    rigger = require('gulp-rigger'),
    cssmin = require('gulp-minify-css'),
    imagemin = require('gulp-imagemin'),
    pngquant = require('imagemin-pngquant'),
    rimraf = require('rimraf'),
    browserSync = require("browser-sync"),
    reload = browserSync.reload;

var path = {
    dist: {
        html: 'dist/',
        scripts: 'dist/scripts/',
        styles: 'dist/styles/',
        images: 'dist/images/',
        favicon: 'dist/'
    },
    src: {
        html: {
            index: 'src/index*html',
            product: 'src/product*html',
            collection: 'src/collection*html',
            blog: 'src/blog*html',
            gallery: 'src/gallery*html',
            page: 'src/page*html',
            other: 'src/other*html'
        },
        scripts: {
            theme: [
                'src/scripts/theme.js',
                'src/scripts/module.*.js',
                'src/scripts/section.*.js'
            ],
            vendor: 'src/scripts/vendor.min.js',
            plugin: 'src/scripts/plugin.*.js'
        },
        css: 'src/css/*.css',
        scss: 'src/scss/*.scss',
        images: 'src/images/**/*.*',
        favicon: 'src/favicon.*'
    },
    watch: {
        html: {
            index: 'src/index*html',
            product: 'src/product*html',
            collection: 'src/collection*html',
            blog: 'src/blog*html',
            gallery: 'src/gallery*html',
            page: 'src/page*html',
            other: 'src/other*html'
        },
        scripts: {
            theme: [
                'src/scripts/theme.js',
                'src/scripts/module.*.js',
                'src/scripts/section.*.js'
            ],
            vendor: 'src/scripts/vendor.min.js',
            plugin: 'src/scripts/plugin.*.js'
        },
        css: 'src/css/*.css',
        scss: 'src/scss/**/*.scss',
        images: 'src/images/**/*.*',
        favicon: 'src/favicon.*'
    },
    clean: './dist'
};

var config = {
    server: {
        baseDir: "./dist"
    },
    tunnel: true,
    host: 'localhost',
    port: 9000,
    logPrefix: "Frontend_Devil"
};

gulp.task('html-index:build', function () {
    gulp.src(path.src.html.index)
        .pipe(rigger())
        .pipe(gulp.dest(path.dist.html))
        .pipe(reload({stream: true}));
});

gulp.task('html-product:build', function () {
    gulp.src(path.src.html.product)
        .pipe(rigger())
        .pipe(gulp.dest(path.dist.html))
        .pipe(reload({stream: true}));
});

gulp.task('html-collection:build', function () {
    gulp.src(path.src.html.collection)
        .pipe(rigger())
        .pipe(gulp.dest(path.dist.html))
        .pipe(reload({stream: true}));
});

gulp.task('html-blog:build', function () {
    gulp.src(path.src.html.blog)
        .pipe(rigger())
        .pipe(gulp.dest(path.dist.html))
        .pipe(reload({stream: true}));
});

gulp.task('html-gallery:build', function () {
    gulp.src(path.src.html.gallery)
        .pipe(rigger())
        .pipe(gulp.dest(path.dist.html))
        .pipe(reload({stream: true}));
});

gulp.task('html-page:build', function () {
    gulp.src(path.src.html.page)
        .pipe(rigger())
        .pipe(gulp.dest(path.dist.html))
        .pipe(reload({stream: true}));
});

gulp.task('html-other:build', function () {
    gulp.src(path.src.html.other)
        .pipe(rigger())
        .pipe(gulp.dest(path.dist.html))
        .pipe(reload({stream: true}));
});

gulp.task('scripts-theme:build', function () {
    gulp.src(path.src.scripts.theme)
        .pipe(rigger())
        .pipe(gulp.dest(path.dist.scripts))
        .pipe(reload({stream: true}));

    gulp.src(path.src.scripts.theme)
        .pipe(rigger())
        //.pipe(sourcemaps.init())
        .pipe(uglify())
        //.pipe(sourcemaps.write())
        .pipe(extReplace('.min.js', '.js'))
        .pipe(gulp.dest(path.dist.scripts))
        .pipe(reload({stream: true}));
});

gulp.task('scripts-vendor:build', function () {
    gulp.src(path.src.scripts.vendor)
        .pipe(rigger())
        .pipe(gulp.dest(path.dist.scripts))
        .pipe(reload({stream: true}));
});

gulp.task('scripts-plugin:build', function () {
    gulp.src(path.src.scripts.plugin)
        .pipe(gulp.dest(path.dist.scripts))
        .pipe(reload({stream: true}));
});

gulp.task('scss:build', function () {
    gulp.src(path.src.scss)
        .pipe(sass())
        .pipe(prefixer())
        .pipe(gulp.dest(path.dist.styles))
        .pipe(reload({stream: true}));

    gulp.src(path.src.scss)
        //.pipe(sourcemaps.init())
        .pipe(sass())
        .pipe(prefixer())
        .pipe(cssmin())
        //.pipe(sourcemaps.write())
        .pipe(extReplace('.min.css', '.css'))
        .pipe(gulp.dest(path.dist.styles))
        .pipe(reload({stream: true}));
});

gulp.task('css:build', function() {
    gulp.src(path.src.css)
        .pipe(gulp.dest(path.dist.styles))
        .pipe(reload({stream: true}));
});

gulp.task('images:build', function () {
    gulp.src(path.src.images)
        .pipe(imagemin({
            progressive: true,
            svgoPlugins: [{removeViewBox: false}],
            use: [pngquant()],
            interlaced: true
        }))
        .pipe(gulp.dest(path.dist.images))
        .pipe(reload({stream: true}));
});

gulp.task('favicon:build', function() {
    gulp.src(path.src.favicon)
        .pipe(gulp.dest(path.dist.favicon))
        .pipe(reload({stream: true}));
});

gulp.task('watch', function(){
    gulp.start('webserver');
    
    watch([path.watch.html.index], function(event, cb) {
        gulp.start('html-index:build');
    });
    watch([path.watch.html.product], function(event, cb) {
        gulp.start('html-product:build');
    });
    watch([path.watch.html.collection], function(event, cb) {
        gulp.start('html-collection:build');
    });
    watch([path.watch.html.blog], function(event, cb) {
        gulp.start('html-blog:build');
    });
    watch([path.watch.html.gallery], function(event, cb) {
        gulp.start('html-gallery:build');
    });
    watch([path.watch.html.page], function(event, cb) {
        gulp.start('html-page:build');
    });
    watch([path.watch.html.other], function(event, cb) {
        gulp.start('html-other:build');
    });
    watch([path.watch.scss], function(event, cb) {
        gulp.start('scss:build');
    });
    watch([path.watch.css], function(event, cb) {
        gulp.start('css:build');
    });
    watch([path.watch.scripts.theme[0]], function(event, cb) {
        gulp.start('scripts-theme:build');
    });
    watch([path.watch.scripts.theme[1]], function(event, cb) {
        gulp.start('scripts-theme:build');
    });
    watch([path.watch.scripts.theme[2]], function(event, cb) {
        gulp.start('scripts-theme:build');
    });
    watch([path.watch.scripts.vendor], function(event, cb) {
        gulp.start('scripts-vendor:build');
    });
    watch([path.watch.scripts.plugin], function(event, cb) {
        gulp.start('scripts-plugin:build');
    });
    watch([path.watch.images], function(event, cb) {
        gulp.start('images:build');
    });
    watch([path.watch.favicon], function(event, cb) {
        gulp.start('favicon:build');
    });
});

gulp.task('webserver', function () {
    browserSync(config);
});

gulp.task('clean', function (cb) {
    rimraf(path.clean, cb);
});

gulp.task('html:build', [
    'html-index:build',
    'html-product:build',
    'html-collection:build',
    'html-blog:build',
    'html-gallery:build',
    'html-page:build',
    'html-other:build'
]);

gulp.task('scripts:build', [
    'scripts-theme:build',
    'scripts-vendor:build',
    'scripts-plugin:build'
]);

gulp.task('styles:build', [
    'scss:build',
    'css:build'
]);

gulp.task('build', [
    'html:build',
    'scripts:build',
    'styles:build',
    'images:build',
    'favicon:build'
]);

gulp.task('default', ['build', 'webserver', 'watch']);
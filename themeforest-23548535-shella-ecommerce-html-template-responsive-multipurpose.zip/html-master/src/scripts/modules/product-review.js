theme.ProductReview = function() {

    function ProductReview() {

    };

    ProductReview.prototype = $.extend({}, ProductReview.prototype, {
        update: function() {
            
        }
    });

    theme.ProductReview = new ProductReview;
};